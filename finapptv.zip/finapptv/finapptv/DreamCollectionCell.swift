//
//  DreamCollectionCell.swift
//  finapptv


import UIKit

class DreamCollectionCell: UICollectionViewCell {
    
    /*REGION IBOUTLETS*/
    @IBOutlet weak var imgCollectionDream: UIImageView!
    @IBOutlet weak var lblCollectionDream: UILabel!
    /*ENDREGION IBOUTLETS*/
    
    /*REGION MÈTODES*/
    func setDreamCollection(dream: Dream)
    {
        self.imgCollectionDream.image = UIImage(named: dream.imagePath)
        self.lblCollectionDream.text = dream.title
    }
    /*ENDREGION MÈTODES*/
    
}
