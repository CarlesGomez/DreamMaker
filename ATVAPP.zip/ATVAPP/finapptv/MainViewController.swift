//
//  ViewController.swift
//  finapptv


import UIKit
import AVKit

class MainViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UICollectionViewDelegateFlowLayout {

    /*REGION IBOUTLETS*/
    @IBOutlet weak var dreamList: UITableView!
    @IBOutlet weak var dreamCollection: UICollectionView!
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var lblVideo: UILabel!
    @IBOutlet weak var btnVideo: UIButton!
    /*ENDREGION IBOUTLETS*/
    
    /*REGION VARIABLES*/
    var collectionDreams = [Dream]()
    var savedDreams = [Dream]()
    var lastDreamClicked:Dream = Dream(id: "0", title: "", videoPath: "", imagePath: "", price: "0", finModels: [])
    var player = AVPlayer()
    var playerController = AVPlayerViewController()
    private var storyboardMine: UIStoryboard = UIStoryboard()
    /*ENDREGION VARIABLES*/
    
    /*REGION EVENTS*/
    override func viewDidLoad() {
        super.viewDidLoad()
        storyboardMine = UIStoryboard(name: "Main", bundle: nil)
        initDreams()
        /*NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: "getDreamLiked", userInfo: nil, repeats: true)*/
        startPhotosCamera()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnAddDreamToWishList(sender: AnyObject) {
        if !savedDreamsContainsId(self.lastDreamClicked) && self.lastDreamClicked.id != "0"
        {
            self.savedDreams.append(self.lastDreamClicked)
            let dreamsData = NSKeyedArchiver.archivedDataWithRootObject(self.savedDreams)
            NSUserDefaults.standardUserDefaults().setObject(dreamsData, forKey: "myDreams")
            sendDreamsToServer()
        }
        self.dreamList.reloadData()
    }

    /*ENDREGION EVENTS*/
    
    /*REGION TABLEVIEW EVENTS*/
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell: DreamListCell = tableView.dequeueReusableCellWithIdentifier("dreamListCell") as! DreamListCell
        
        cell.setListDream(savedDreams[indexPath.row])
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return savedDreams.count
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    /*ENDREGION TABLEVIEW EVENTS*/
    
    /*REGION COLLECTIONVIEW*/
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionDreams.count
    }
    
    //--- MARK: PresentModally manual i fer event didselectItemAtIndexPath
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell:DreamCollectionCell = collectionView.dequeueReusableCellWithReuseIdentifier("dreamCollectionCell", forIndexPath: indexPath) as! DreamCollectionCell
        
        cell.setDreamCollection(collectionDreams[indexPath.row])
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        
        self.lastDreamClicked = collectionDreams[indexPath.row]
        playVideo(self.lastDreamClicked)
    }
    /*ENDREGION COLLECTIONVIEW*/
    
    /*REGION MÈTODES*/
    func initDreams()
    {
        collectionDreams = [
            Dream(id: "1", title: "Apple Watch", videoPath: NSBundle.mainBundle().pathForResource("AppleWatch", ofType:"mp4")!, imagePath: "watch", price: "819 €",
                finModels:[
                    FinModel(title: "Consíguelo con un préstamo", link: "https://portal.lacaixa.es/prestamoshipotecas/prestamoshipotecas_es.html")
                ]),
            Dream(id: "2", title: "BMW Serie 1", videoPath: NSBundle.mainBundle().pathForResource("BMWCompartelo", ofType:"mp4")!, imagePath: "bmw", price: "26.500 €",
                finModels:[
                    FinModel(title: "Consíguelo con un préstamo", link: "https://portal.lacaixa.es/prestamoshipotecas/prestamoshipotecas_es.html"),
                    FinModel(title: "Asegurar el coche", link: "https://portal.lacaixa.es/segurcaixaauto/homesegurcaixaauto_es.html")
                ]),
            Dream(id: "3", title: "Plan de jubilación", videoPath: NSBundle.mainBundle().pathForResource("Caixafuturospot", ofType:"mp4")!, imagePath: "caixa", price: "500 €/mes",
                finModels:[
                    FinModel(title: "Asegurar mi futuro", link: "https://portal.lacaixa.es/caixafuturo/caixafuturo_es.html")
                ]),
            Dream(id: "4", title: "Crucero por el mediterráneo", videoPath: NSBundle.mainBundle().pathForResource("CostaCruceros", ofType:"mp4")!, imagePath: "costa", price: "449 €",
                finModels:[
                    FinModel(title: "Viajar sin preocupaciones", link: "https://portal.lacaixa.es/seguros/segurcaixaasistenciaenviaje_es.html"),
                    FinModel(title: "Consíguelo con un préstamo", link: "https://portal.lacaixa.es/prestamoshipotecas/prestamoshipotecas_es.html")
                ])
        ]
        
        let dreamsData = NSUserDefaults.standardUserDefaults().objectForKey("myDreams") as? NSData
        
        if let dreamsData = dreamsData
        {
            let dreamsArray = NSKeyedUnarchiver.unarchiveObjectWithData(dreamsData) as? [Dream]
            
            if let dreamsArray = dreamsArray
            {
                for(var i = 0; i < dreamsArray.count;i++)
                {
                    savedDreams.append(dreamsArray[i])
                }
            }
        }
    }
    
    func playVideo(dream: Dream)
    {
        let path = dream.videoPath
        let url = NSURL.fileURLWithPath(path)
        
        player = AVPlayer(URL: url)
        playerController = AVPlayerViewController()
        playerController.player = player
        
        playerController.removeFromParentViewController()
        self.addChildViewController(playerController)
        
        playerController.view.removeFromSuperview()
        self.view.addSubview(playerController.view)
        self.view.addSubview(lblVideo)

        var btnPadding = CGRectMake(self.btnVideo.frame.origin.x + 10, self.btnVideo.frame.origin.y + 10, self.btnVideo.frame.width - 20, self.btnVideo.frame.height - 20)
        
        playerController.view.frame = btnPadding
        player.play()
    }
    
    func savedDreamsContainsId(dream: Dream) -> Bool
    {
        for(var i = 0; i < self.savedDreams.count; i++)
        {
            if(self.savedDreams[i].id == dream.id)
            {
                return true
            }
        }
        return false
    }
    
    func sendDreamsToServer()
    {
        var stringDreams = dreamsToString(self.savedDreams)
        
        let task = TaskQueue()
        
        //Do in background.
        task.tasks +=~ { result, next in
            
            let request = NSMutableURLRequest(URL: NSURL(string: "http://sompartyapp.com/appletv/real/insertDreams.php")!)
            request.HTTPMethod = "POST"
            
            //POST Strings:
            
            let postString = StringBuilder()
            
            postString.append("dreams" + "=" + stringDreams)
            
            let postFinal : String = postString.toString()
            
            request.HTTPBody = postFinal.dataUsingEncoding(NSUTF8StringEncoding)
            
            
            NSURLSession.sharedSession().dataTaskWithRequest(request,
                completionHandler: {(data: NSData?, response: NSURLResponse?, error: NSError?) in
                    //Process the response
                    if error != nil
                    {
                        print("~ERROR: \(error)")
                        return
                    }
                    else
                    {
                        print("In Background dreams")
                        next(nil)
                    }
            }).resume()
        }
        
        task.tasks +=! {
            //Post Execute tmb.
        }
        
        task.run {
            print("Post execute register dreams")
        };
    }
    
    func dreamsToString(dreamsArray: [Dream]) -> String {
        var toReturn = ""
        
        var sb = StringBuilder()
        for dream in dreamsArray{
            
            sb.append(dream.id).append(":")
        }
        toReturn = sb.toString()
        return toReturn
    }
    
    //No s'utilitza.
    func getDreamLiked()
    {
        var dataMine:NSData?
        let task = TaskQueue()
        
        //Do in background.
        task.tasks +=~ { result, next in
            
            var request = NSMutableURLRequest(URL: NSURL(string: "http://sompartyapp.com/appletv/real/selectRasp.php")!)
            
            NSURLSession.sharedSession().dataTaskWithRequest(request,
                completionHandler: {(data: NSData?, response: NSURLResponse?, error: NSError?) in
                    //process the response
                    if error != nil
                    {
                        print(error)
                        return
                    }
                    else
                    {
                        dataMine = data
                        print("In Background getRasp")
                        next(nil)
                    }
            }).resume()
        }
        
        task.tasks +=! {
            //Post Execute tmb.
        }
        
        task.run {
            print("Post execute getRasp")
            print("----")
            
            var string = NSString(data: dataMine!, encoding: NSUTF8StringEncoding)
            string = "\(string)"
            
            var stringMine = ""
            if(string == "Optional(like)")
            {
                stringMine = "like"
            }
            if(stringMine == "like" && self.lastDreamClicked.id != "0")
            {
                self.btnVideo.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
            }
            print(stringMine)
        };
    }
    
    func startPhotosCamera()
    {
        var dataMine:NSData?
        let task = TaskQueue()
        
        //Do in background.
        task.tasks +=~ { result, next in
            
            var request = NSMutableURLRequest(URL: NSURL(string: "http://192.168.10.32/viewvideo.php")!)
            
            NSURLSession.sharedSession().dataTaskWithRequest(request,
                completionHandler: {(data: NSData?, response: NSURLResponse?, error: NSError?) in
                    //process the response
                    if error != nil
                    {
                        print(error)
                        return
                    }
                    else
                    {
                        dataMine = data
                        print("In Background startPhotosCamera")
                        next(nil)
                    }
            }).resume()
        }
        
        task.tasks +=! {
            //Post Execute tmb.
        }
        
        task.run {
            print("Post execute startPhotosCamera")
            print("----")
            
            var string = NSString(data: dataMine!, encoding: NSUTF8StringEncoding)
            string = "\(string)"
            
            var stringMine = ""
            if(string == "Optional(like)")
            {
                stringMine = "like"
            }
            if(stringMine == "like" && self.lastDreamClicked.id != "0")
            {
                self.btnVideo.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
            }
            print(string)
            self.startPhotosCamera()
        };
    }
    
    /*ENDREGION MÈTODES*/

}

