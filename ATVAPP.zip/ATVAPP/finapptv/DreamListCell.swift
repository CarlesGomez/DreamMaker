//
//  DreamListCell.swift
//  finapptv
//

import UIKit

class DreamListCell: UITableViewCell {

    /*REGION IBOUTLETS*/
    @IBOutlet weak var imgDream: UIImageView!
    @IBOutlet weak var lblDream: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    /*ENDREGION IBOUTLETS*/
    
    /*REGION EVENTS*/
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    /*ENDREGION EVENTS*/
    
    /*REGION MÈTODES*/
    func setListDream(dream: Dream)
    {
        self.imgDream.image = UIImage(named: dream.imagePath)
        self.lblDream.text = dream.title
        self.lblPrice.text = dream.price
    }
    /*ENDREGION MÈTODES*/

}
